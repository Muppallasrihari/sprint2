package com.cg.healthify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercisetoolapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
