package com.cg.healthify.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ExercisePlanIdException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ExercisePlanIdException() {
		super();
	}
	
	public ExercisePlanIdException(String errMsg) {
		super(errMsg);
	}

}
